﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public static class RegisterServices
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.RegisterAssemblyTypes(typeof(RegisterServices), ServiceLifetime.Transient, "Service");
            //services.AddSingleton<ILogger, AppInsightLogger>();
            return services;
        }

        public static IIdentityServerBuilder AddIdentityServices(this IIdentityServerBuilder identityServer)
        {
            return identityServer.AddProfileService<IdentityProfileService>()
                .AddResourceOwnerValidator<ResourceOwnerPasswordValidatorService>();
        }
    }
}
