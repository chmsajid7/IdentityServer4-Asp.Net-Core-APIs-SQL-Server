﻿using IdentityServer4.EntityFramework.DbContexts;
using IdentityServer4.EntityFramework.Mappers;
using IdentityServer4.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public static class InitializeDbStartup
    {
        public static void InitializeDatabase(this IApplicationBuilder app, IWebHostEnvironment env)
        {
            using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetRequiredService<ConfigurationDbContext>();
                serviceScope.ServiceProvider.GetRequiredService<PersistedGrantDbContext>().Database.Migrate();

                if (!context.ApiResources.Any())
                {
                    IEnumerable<ApiResource> apiResources = GetDefaultValues<IEnumerable<ApiResource>>(Path.Combine("ApiResources.json"));
                    foreach (var resource in apiResources)
                    {
                        context.ApiResources.Add(resource.ToEntity());
                    }
                    context.SaveChanges();
                }

                if (!context.Clients.Any())
                {
                    string path = Path.Combine("Clients.json");

                    Client client = GetDefaultValues<Client>(path);
                    context.Clients.Add(new Client
                    {
                        ClientId = client.ClientId,
                        ClientName = client.ClientName,
                        ClientSecrets = {new Secret(GetPropertyValue(path,"Secret").Sha256())},
                        AccessTokenLifetime = client.AccessTokenLifetime,
                        AbsoluteRefreshTokenLifetime = client.AbsoluteRefreshTokenLifetime,
                        AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,
                        AllowedScopes = client.AllowedScopes,
                        AllowOfflineAccess = true,
                    }.ToEntity());
                    context.SaveChanges();
                }

                var roleManager = app.ApplicationServices.CreateScope().ServiceProvider.GetService<RoleManager<IdentityRole>>();
                if (!roleManager.Roles.Any())
                {
                    AddDefaultRoles(roleManager, env);
                    
                    string path = Path.Combine("User.json");
                    DefaultUser user = GetDefaultValues<DefaultUser>(path);
                    
                    var userManager = app.ApplicationServices.CreateScope().ServiceProvider.GetService<UserManager<AppUser>>();
                    AppUser appUser = new AppUser
                    {
                        EmailConfirmed = true,
                        Email = user.Email,
                        UserName = user.Username
                    };
                    userManager.CreateAsync(appUser, user.Password).Wait();
                    userManager.AddToRolesAsync(appUser, user.Roles).Wait();
                }
            }
        }

        private static void AddDefaultRoles(RoleManager<IdentityRole> roleManager, IWebHostEnvironment env)
        {
            IEnumerable<string> DefaultRoles = GetDefaultValues<IEnumerable<string>>(Path.Combine("Roles.json"));
            foreach (var role in DefaultRoles)
            {
                roleManager.CreateAsync(new IdentityRole { Name = role }).Wait();
            }
        }

        private static T GetDefaultValues<T>(string path)
        {
            string jsonString = File.ReadAllText(path);
            return JsonConvert.DeserializeObject<T>(jsonString);
        }

        private static string GetPropertyValue(string path, string propertyName)
        {
            string jsonString = File.ReadAllText(path);
            return JObject.Parse(jsonString).SelectToken(propertyName).Value<string>();
        }
    }

    public class DefaultUser
    {
        public string Email { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public IEnumerable<string> Roles { get; set; }
    }
}
