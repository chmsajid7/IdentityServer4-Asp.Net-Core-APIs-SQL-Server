﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public static class RegisterAssembly
    {
        public static IServiceCollection RegisterAssemblyTypes(this IServiceCollection services, Type assemblyType, ServiceLifetime serviceLifetime, string postFix = null)
        {
            Assembly assembly = Assembly.GetAssembly(assemblyType);
            Type[] types = assembly.GetTypes();
            IEnumerable<Type> typesOfClasses = string.IsNullOrEmpty(postFix) ? types.Where(x => x.IsClass && x.IsAssignableFrom(x)) : types.Where(x => x.IsClass && x.IsAssignableFrom(x) && x.Name.EndsWith(postFix));
            foreach (Type classType in typesOfClasses)
            {
                Type[] interfaces = classType.GetInterfaces();
                if (interfaces.Length > 0)
                {
                    services.ResolveAllInterfaces(classType, interfaces, serviceLifetime);
                }
            }
            return services;
        }

        private static void ResolveAllInterfaces(this IServiceCollection services, Type classType, Type[] interfaces, ServiceLifetime serviceLifetime)
        {
            foreach (Type interfaceType in interfaces)
            {
                services.Add(new ServiceDescriptor(interfaceType, classType, serviceLifetime));
            }
        }
    }
}
