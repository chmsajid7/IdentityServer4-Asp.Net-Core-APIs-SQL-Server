﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public class InternalCommunicationHandler : AuthorizationHandler<InternalCommunicationRequirement>
    {
        private readonly IHttpContextAccessor httpContextAccessor;

        public InternalCommunicationHandler(IHttpContextAccessor httpContextAccessor)
        {
            this.httpContextAccessor = httpContextAccessor;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, InternalCommunicationRequirement requirement)
        {
            IConfiguration configuration = (IConfiguration)httpContextAccessor.HttpContext.RequestServices.GetService(typeof(IConfiguration));
            try
            {
                AuthenticationHeaderValue authHeader = AuthenticationHeaderValue.Parse(httpContextAccessor.HttpContext.Request.Headers["Authorization"]);
                var authEncodedToken = (authHeader.Parameter);

                //var userName = configuration["InternalCommunication:Username"];
                //var password = configuration["InternalCommunication:Password"];

                var userName = "IdentityServerDemo";
                var password = "Abc@123";

                if (ValidateToken(authEncodedToken, userName, password))
                    context.Succeed(requirement);
                else
                    context.Fail();
            }
            catch
            {
                context.Fail();
            }
            return Task.FromResult(0);
        }

        private string GetDetailsFromToken(string userName, string password)
        {
            string encoded = Convert.ToBase64String(Encoding.Default.GetBytes(userName + ":" + password));
            return encoded;
        }

        private bool ValidateToken(string encodedToken, string userName, string password) =>
            GetDetailsFromToken(userName, password) == encodedToken;

    }
}
