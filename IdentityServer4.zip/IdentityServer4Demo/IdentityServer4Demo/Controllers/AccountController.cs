﻿using IdentityModel.Client;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace IdentityServer4Demo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly SignInManager<AppUser> signInManager;
        private readonly UserManager<AppUser> userManager;
        private readonly IDiscoveryCache discoveryCache;
        public AccountController(SignInManager<AppUser> signInManager, UserManager<AppUser> userManager, IDiscoveryCache discoveryCache)
        {
            this.signInManager = signInManager;
            this.userManager = userManager;
            this.discoveryCache = discoveryCache;
        }

        [HttpPost,Route("login")]
        public async Task<Response<LoginResponse>> LoginAsync(Login login)
        {
            Microsoft.AspNetCore.Identity.SignInResult res = await signInManager.PasswordSignInAsync(login.Username, login.Password, false, false);
            if (res.RequiresTwoFactor)
                return new Response<LoginResponse>(System.Net.HttpStatusCode.Accepted, "REQUIRE_TFA");
            else if (res.IsNotAllowed)
                return new Response<LoginResponse>(System.Net.HttpStatusCode.BadRequest, "USER_EMAIl_NOT_VERIFIED");
            else if (!res.Succeeded)
                return new Response<LoginResponse>(System.Net.HttpStatusCode.Unauthorized, "USERNAME_PASSWORD_NOT_MATCH");

            UserKeys userKeys = null;
            AppUser user = await userManager.FindByNameAsync(login.Username);
            if (user != null)
            {
                // NEED TO WORK ON THIS
            }

            return await CreateSessionAsync("USERNAME_PASSWORD_NOT_MATCH", userKeys, login.Username, login.Password);
        }

        private async Task<Response<LoginResponse>> CreateSessionAsync(string message, UserKeys userKeys, string username, string password = ".")
        {
            try
            {
                /*
                if (userKeys == null)
                {
                    message = "COULD_NOT_GET_KEYS";
                    throw new Exception(message);
                }
                */
                DiscoveryDocumentResponse disco = await discoveryCache.GetAsync();
                HttpClient client = new HttpClient();
                TokenResponse tokenResponse = await client.RequestPasswordTokenAsync(new PasswordTokenRequest
                {
                    Address = disco.TokenEndpoint,
                    ClientId = "user_management_auth_ro",
                    ClientSecret = "asdfg@12345!?.",
                    UserName = username,
                    Password = password,
                    Parameters = password == "." ? new Dictionary<string, string> { { "Method","ByPass"} } : new Dictionary<string, string>()
                });
                if (tokenResponse.HttpStatusCode == System.Net.HttpStatusCode.OK)
                {
                    return new Response<LoginResponse>(new LoginResponse(tokenResponse.AccessToken, tokenResponse.ExpiresIn, tokenResponse.RefreshToken));
                }
                return new Response<LoginResponse>(System.Net.HttpStatusCode.BadRequest, message);
            }
            catch (Exception ex)
            {
                return new Response<LoginResponse>(System.Net.HttpStatusCode.BadRequest, message);
            }
        }
    }
}
