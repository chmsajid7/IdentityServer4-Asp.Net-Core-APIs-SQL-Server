﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public class Login
    {
        [Required(ErrorMessage = "REQUIRED")]
        public string Username { get; set; }
        [Required(ErrorMessage = "REQUIRED")]
        public string Password { get; set; }
        public string ExpoToken { get; set; }

        internal LoginDetails ToDto()
        {
            return new LoginDetails
            {
                Username = Username,
                Password = Password,
                ExpoToken = ExpoToken
            };
        }
    }
}
