﻿using IdentityServer4.Models;
using IdentityServer4.Validation;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public class ResourceOwnerPasswordValidatorService : IResourceOwnerPasswordValidator
    {
        private readonly UserManager<AppUser> userManager;

        public ResourceOwnerPasswordValidatorService(UserManager<AppUser> userManager)
        {
            this.userManager = userManager;
        }

        public async Task ValidateAsync(ResourceOwnerPasswordValidationContext context)
        {
            AppUser identityUser = await userManager.FindByNameAsync(context.UserName);
            if (identityUser == null)
            {
                context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant, "USERNAME_PASSWORD_NOT_MATCH");
                return;
            }

            if (!context.Request.Raw.Get("Method")?.Equals("ByPass") ?? true)
            {
                bool isPasswordValid = await userManager.CheckPasswordAsync(identityUser, context.Password);
                if (!isPasswordValid)
                {
                    context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant, "USERNAME_PASSWORD_NOT_MATCH");
                    return;
                }
            }
            context.Result = new GrantValidationResult(
                            subject: identityUser.Id,
                            authenticationMethod: "custom",
                            claims: GetUserClaims(identityUser));
        }

        public static Claim[] GetUserClaims(AppUser user)
        {
            return new Claim[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id),
                new Claim(JwtRegisteredClaimNames.Email, user.Email)
            };
        }
    }
}
