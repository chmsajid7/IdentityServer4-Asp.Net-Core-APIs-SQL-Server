﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public class ResultData
    {
        internal ResultData() { }
        public string Message { get; set; }
        public IEnumerable<string> Errors { get; set; }
        public ResponseCode Code { get; set; }
        public bool Status { get; set; }
        [JsonIgnore]
        public bool Conflict { get; set; }

        public ResultData(bool status, string message)
        {
            Status = status;
            Message = message;
        }

        public ResultData(bool status, string message, bool isConflict)
        {
            Status = status;
            Message = message;
            Conflict = isConflict;
        }

        public ResultData(IEnumerable<string> errors)
        {
            Errors = errors;
            Status = false;
            Code = ResponseCode.Errors;
        }

        public ResultData(IEnumerable<string> errors, bool isConflict)
        {
            Errors = errors;
            Status = false;
            Code = ResponseCode.Errors;
            Conflict = isConflict;
        }

        internal ResultData(string message, ResponseCode code = ResponseCode.Message)
        {
            Message = message;
            Code = code;
            Status = Code == ResponseCode.Message;
        }
    }

    public class ResultData<T> : ResultData
    {
        public T Data { get; internal set; }
        internal ResultData() { }
        internal ResultData(T data)
        {
            Status = true;
            Data = data;
            Code = ResponseCode.Data;
        }
        internal ResultData(string message, ResponseCode code = ResponseCode.Message)
        {
            Message = message;
            Code = code;
        }

        internal ResultData(IEnumerable<string> errors)
        {
            Errors = errors;
            Code = ResponseCode.Errors;
        }

    }
    

    public enum ResponseCode
    {
        Error = 0,
        Errors = 2,
        Message = 4,
        Data = 8
    }
}
