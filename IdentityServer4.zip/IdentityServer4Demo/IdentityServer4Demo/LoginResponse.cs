﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public class LoginResponse : UserKeys
    {
        public string RefreshToken { get; set; }
        public string AccessToken { get; set; }
        public DateTime ExpiresIn { get; set; }
        public LoginResponse(string accessToken, int expiry, string refreshToken)
        {
            AccessToken = accessToken;
            ExpiresIn = DateTime.UtcNow.AddSeconds(expiry);
            RefreshToken = refreshToken;
        }
    }
}
