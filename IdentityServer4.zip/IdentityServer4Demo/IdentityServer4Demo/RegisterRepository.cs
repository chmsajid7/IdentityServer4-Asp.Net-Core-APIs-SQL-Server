﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public static class RegisterRepository
    {
        public static IServiceCollection AddRepository(this IServiceCollection services)
        {
            services.RegisterAssemblyTypes(typeof(RegisterAssembly), ServiceLifetime.Transient, "Repository");
            return services;
        }

        public static IServiceCollection AddUserIdentity(this IServiceCollection services, Action<IdentityOptions> options, string connectionString)
        {
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(connectionString, x => x.MigrationsAssembly(typeof(RegisterRepository).Assembly.GetName().Name)));

            services.AddIdentity<AppUser, IdentityRole>(options)
                .AddEntityFrameworkStores<ApplicationDbContext>()
                .AddDefaultTokenProviders();
            //.AddErrorDescriber<MultilanguageIdentityErrorDescriber>();

            return services;
        }

        public static IIdentityServerBuilder AddIdentityServer(this IServiceCollection services, string connectionString)
        {
            string migrationsAssembly = typeof(RegisterRepository).Assembly.GetName().Name;
            return services.AddIdentityServer()
                .AddConfigurationStore(options =>
                {
                    options.ConfigureDbContext = b =>
                    b.UseSqlServer(connectionString,
                    sql => sql.MigrationsAssembly(migrationsAssembly));
                })
                .AddOperationalStore(options =>
                {
                    options.ConfigureDbContext = b =>
                    b.UseSqlServer(connectionString,
                    sql => sql.MigrationsAssembly(migrationsAssembly));
                    options.EnableTokenCleanup = true;
                });
        }
    }
}
