﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityServer4Demo
{
    public class UserKeys
    {
        public string Secret { get; set; }
        public string PublicKey { get; set; }
        public string UserId { get; set; }
    }
}
